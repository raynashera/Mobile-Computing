//
//  W03_TakeHome_RaynaSheraChangApp.swift
//  W03_TakeHome_RaynaSheraChang
//
//  Created by jessica tedja on 29/09/25.
//

import SwiftUI

@main
struct W03_TakeHome_RaynaSheraChangApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
