//
//  ContentView.swift
//  W03_TakeHome_RaynaSheraChang_0706022310022
//
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            HomePage()
                .tabItem {
                    Label("Home", systemImage: "house.fill")
                }
            LocationPage()
                .tabItem {
                    Label("Location", systemImage: "location.fill")
                }
            StatsPage()
                .tabItem {
                    Label("Stats", systemImage: "chart.bar.fill")
                }
            SettingPage()
                .tabItem {
                    Label("Setting", systemImage: "gearshape.fill")
                }
        }
        .tint(.red)
    }
}


struct HomePage: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Good Morning,")
                        .font(.headline)
                        .foregroundStyle(.secondary)
                    Text("Rayna")
                        .font(.system(size: 37, weight: .bold))
                }
                Spacer()
                Image("rena")
                    .resizable()
                    .scaledToFill()
                    .frame(width: 54, height: 54)
                    .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
            }
            .padding(.horizontal)
            
            TextField("Search", text: .constant(""))
                .padding()
                .background(Color(.white))
                .cornerRadius(14)
                .padding(.horizontal)
            
            VStack(alignment: .leading, spacing: 14) {
                HStack {
                    Spacer()
                    Text("Today’s Goal")
                        .font(.system(size: 29, weight: .bold))
                        .foregroundColor(.white)
                    Spacer()
                }
                .padding()
                HStack(spacing: 16) {
                    // Left small card
                    VStack(spacing: 8) {
                        Image(systemName: "figure.walk")
                            .font(.system(size: 45, weight: .semibold))
                            .foregroundColor(.white)
                        Text("4 Miles")
                            .font(.system(size: 24))
                            .fontWeight(.bold)
                            .foregroundColor(.white)
                        Text("@Thames Route")
                            .font(.caption)
                            .foregroundColor(.white.opacity(0.85))
                    }
                    .frame(maxWidth: .infinity, minHeight: 160)
                    .background(Color.white.opacity(0.18))
                    .cornerRadius(16)
                    
                    VStack(spacing: 8) {
                        Image(systemName: "sailboat.fill")
                            .font(.system(size: 45, weight: .semibold))
                            .foregroundColor(.white)
                        Text("2 Miles")
                            .font(.system(size: 24))
                            .fontWeight(.bold)
                            .foregroundColor(.white)
                        Text("@River Lea")
                            .font(.caption)
                            .foregroundColor(.white.opacity(0.85))
                    }
                    .frame(maxWidth: .infinity, minHeight: 160)
                    .background(Color.white.opacity(0.18))
                    .cornerRadius(16)
                }
            }
            .padding()
            .background(
                LinearGradient(
                    colors: [Color(red: 0.94, green: 0.23, blue: 0.28), Color(red: 0.62, green: 0.35, blue: 0.98)],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
            )
            .cornerRadius(22)
            .padding(.horizontal)
            
            VStack(spacing: 16) {
                HStack(spacing: 16) {
                    statCard(icon: "heart.fill",
                             iconColor: .purple,
                             valueText: "68 Bpm")
                    statCard(icon: "flame.fill",
                             iconColor: .orange,
                             valueText: "0 Kcal")
                }
                HStack(spacing: 16) {
                    statCard(icon: "scalemass.fill",
                             iconColor: .green,
                             valueText: "73 Kg")
                    statCard(icon: "moon.zzz.fill",
                             iconColor: .blue,
                             valueText: "6.2 Hr")
                }
            }
            .padding(.horizontal)
            
            Spacer(minLength: 12)
        }
        .padding(.top)
        .background(Color(.systemGray6).ignoresSafeArea())
        
    }
    func statCard(icon: String, iconColor: Color, valueText: String) -> some View {
        ZStack {
            RoundedRectangle(cornerRadius: 30)
                .fill(Color.white)
                .shadow(color: .black.opacity(0.06), radius: 6, y: 4)
            VStack {
                HStack {
                    ZStack {
                        Circle()
                            .fill(iconColor.opacity(0.12))
                            .frame(width: 38, height: 38)
                        Image(systemName: icon)
                            .foregroundColor(iconColor)
                    }
                    Spacer()
                }
                Spacer()
                
                HStack {
                    Spacer()
                    Text(valueText)
                        .font(.system(size: 24))
                        .padding(.bottom, 4)
                        .padding(.trailing, 6)
                }
            }
            .padding(10)
        }
        .frame(maxWidth: .infinity, minHeight: 60)
    }
}

struct LocationPage: View {
    var body: some View {
        Text("Location Page")
            .font(.largeTitle)
    }
}

struct StatsPage: View {
    var body: some View {
        Text("Statistic Page")
            .font(.largeTitle)
    }
}

struct SettingPage: View {
    var body: some View {
        Text("Setting Page")
            .font(.largeTitle)
    }
}

#Preview {
    ContentView()
}
