//
//  ContentView.swift
//  W02_ToDoList_RaynaSheraChang_0706022310022
//
//

import SwiftUI

struct ContentView: View {
    
    @State private var tasks: [String] = [
        "Draft UI/UX Figma Lomba",
        "Data Mining Python",
        "ISSG Exercise 1",
        "Pre-Test W2 English Core"
    ]
    
    @State private var deadlines: [String] = [
        "Monday, 22 September 2025 10:00 AM",
        "Tuesday, 23 September 2025 12:00 PM",
        "Friday, 26 September 2025 07:00 PM",
        "Sunday, 28 September 2025 09:00 PM"
    ]
    
    
    @State private var done: Set<Int> = [0]
    @State private var newTask = ""
    @State private var progress: Double = 0.4
    
    var body: some View {
        VStack(spacing: 14) {
            HStack {
                Image(systemName: "person.circle.fill")
                    .resizable()
                    .frame(width: 40, height: 40)
                    .foregroundColor(.purple)
                VStack(alignment: .leading, spacing: 2) {
                    Text("Hello!").font(.subheadline).foregroundStyle(.secondary)
                    Text("Rayna Shera").font(.title2).fontWeight(.semibold)
                }
                Spacer()
                Image(systemName: "bell").font(.title3).fontWeight(.semibold)
            }
            .padding(.horizontal)
            
            VStack(alignment: .leading, spacing: 12) {
                HStack{
                    Text("Your today's To-Do List\nalmost done!").font(.headline).foregroundColor(.white)
                    Spacer()
                    Button {} label : {
                        Image(systemName: "ellipsis")
                            .foregroundColor(.white.opacity(0.9))
                            .padding(8)
                            .background(Color.white.opacity(0.15))
                            .cornerRadius(10)
                    }
                }
                ZStack {
                    Slider(value: $progress, in: 0...1, step: 0.05)
                        .tint(.white)
                        .padding(.bottom)
                    Text("\(Int(progress * 100))%")
                        .padding(.top, 40)
                        .foregroundColor(.white).bold()
                }
            }
            .padding()
            .background(Color.purple.opacity(0.7))
            .cornerRadius(18)
            .padding(.horizontal)
            .padding(.bottom, 15)
            
            HStack {
                TextField("Add New Task...", text: $newTask)
                    .textFieldStyle(.roundedBorder)
                Button("Add") {
                    let t = newTask.trimmingCharacters(in: .whitespacesAndNewlines)
                    if t != "" {
                        tasks.append(t)
                        deadlines.append("Tommorow 10.00 PM")
                        newTask = ""
                    }
                }
                .padding(.horizontal, 12)
                .padding(.vertical, 8)
                .foregroundColor(.white)
                .background(Color.purple)
                .cornerRadius(10)
            }
            .padding(.horizontal)
            
            List {
                ForEach(tasks.indices, id: \.self) { i in
                    HStack(alignment: .top, spacing: 12) {
                        Button {
                            if done.contains(i) { done.remove(i) } else { done.insert(i) }
                        } label: {
                            Image(systemName: done.contains(i) ? "checkmark.circle.fill" : "circle")
                                .foregroundColor(done.contains(i) ? .green : .gray)
                                .font(.title3)
                        }
                        .buttonStyle(.plain)
                        
                        VStack(alignment: .leading, spacing: 4) {
                            //todolist deadline
                            Text(tasks[i])
                                .strikethrough(done.contains(i), color: .secondary)
                                .opacity(done.contains(i) ? 0.6 : 1.0)
                            //tanggal deadline
                            HStack(spacing: 6) {
                                Text(deadlines[i])
                                    .font(.caption)
                                    .foregroundStyle(.red)
                            }
                        }
                        Spacer()
                    }
                }
            }
            .listStyle(.inset)
        }
        .padding(.top, 8)
    }
}

#Preview {
    ContentView()
}
