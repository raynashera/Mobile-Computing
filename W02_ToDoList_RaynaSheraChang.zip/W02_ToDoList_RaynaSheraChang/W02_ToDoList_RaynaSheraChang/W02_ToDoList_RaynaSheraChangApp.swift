//
//  W02_ToDoList_RaynaSheraChangApp.swift
//  W02_ToDoList_RaynaSheraChang
//
//  Created by Jennifer Alicia Litan on 22/09/25.
//

import SwiftUI

@main
struct W02_ToDoList_RaynaSheraChangApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
