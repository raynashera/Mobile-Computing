//
//  Task.swift
//  W05_Rayna
//
//  Created by student on 09/10/25.
//
// Model <<<< harus Fix dari awal
// ViewModel << bergerak
// View << bergerak

import Foundation

struct Task: Identifiable, Codable, Hashable {
    var id = UUID()
    var title: String
    var isCompleted: Bool = false
}
