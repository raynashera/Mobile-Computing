//
//  Fruit.swift
//  W05_Rayna
//
//  Created by student on 09/10/25.
//

import Foundation

struct Fruit: Identifiable, Codable, Hashable {
    let UUID: UUID // Universal Unique ID
    let id: String //A001
    let name: String //Apple
    let color: String //Green
    
    // Identifiable = Who's who
    // Codable = Struct ii bisa komunikasi dengan file lain / API
    // Hashable = Swift bisa melakukan komparasi / track codenya
    
//    ForEach (fruits, id: \.name) (fruit) in {
//        
//    }
}
