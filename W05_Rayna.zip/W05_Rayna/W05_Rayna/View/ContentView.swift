//
//  ContentView.swift
//  W05_Rayna
//
//  Created by student on 09/10/25.
//

// Model - ViewModel - View

import SwiftUI

struct CounterHomeView: View {
    @State private var vm = CounterVM()
    
    var body: some View {
        //view gaboleh melakukan apa", karena sumber kebenaran ada di viewModel. source ny dri VM
        NavigationStack {
            VStack(spacing: 16) {
                Text("Count: \(vm.count)")
                    .font(.largeTitle).bold()
                Text(vm.isEven ? "Even" : "Odd")
                    .foregroundStyle(.secondary)
                HStack(spacing: 10) {
                    Button("+") {vm.increment()}
                        .buttonStyle(.bordered)
                    Button("-") {vm.decrement()}
                        .buttonStyle(.bordered)
                }
                Button("Reset") {vm.reset()}
                    .buttonStyle(.borderedProminent)
            }
            NavigationLink("Mirror Screen") {
                CounterMirrorView(vm:vm)
            }
        }
    }
}

struct CounterMirrorView: View {
    var vm: CounterVM
    
    var body: some View {
        VStack(spacing: 16) {
            Text("Mirror Count: \(vm.count)")
            Button("Add Here") {vm.increment()}
        }
        .font(.title2)
        .padding()
    }
}

#Preview {
    CounterHomeView()
}
