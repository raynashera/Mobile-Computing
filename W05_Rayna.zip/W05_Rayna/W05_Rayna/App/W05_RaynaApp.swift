//
//  W05_RaynaApp.swift
//  W05_Rayna
//
//  Created by student on 09/10/25.
//

import SwiftUI

@main
struct W05_RaynaApp: App {
    var body: some Scene {
        WindowGroup {
            MovieHomeView()
        }
    }
}
