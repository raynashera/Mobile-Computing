//
//  ContentView.swift
//  W01_Rayna
//
//  Created by student on 11/09/25.
//

import SwiftUI

struct Student {
    var name: String
    var year: Int
    func display() -> String {
        "\(name) is \(year) year old"
    }
}

enum UserStatus {case offline, online, busy}


struct ContentView: View {
    let userName = "Rayna"
    let scores = [89, 84, 100]
    let student = Student(name: "Shera", year: 10)
    let status: UserStatus = .online
    
    var badge: String {
        scores.allSatisfy { $0 >= 85} ? "✅" : "❌"
    }
    
    var body: some View {
        VStack(spacing: 15) {
            //materi lain
//            Text("Hello, \(userName)")
//                .font(.title)
//            Text("Student: \(student.display())")
//            
//            Text("Status: \(status == .online ? "🟢 Online" :"🔴 Offline")")
//            
//            Text("Badge: \(badge)")
                
            
            //assignment
            HStack{
                Image("rayna")
                    .resizable()
                    .frame(width: 300, height: 200)
                    .clipShape(Circle())
                    .shadow(color: Color.green.opacity(0.9), radius: 60)
                    .padding(.vertical,70)
                    .padding(.top,60)
            }
            
            HStack {
                Text("Hi!, I'm Rayna")
                    .fontWeight(.bold)
                    .font(.largeTitle)
                    .foregroundStyle(
                        LinearGradient(
                            colors: [.green, .pink, .blue],
                            startPoint: .leading,
                            endPoint: .trailing
                    ))
               
                    
            }
            HStack {
                Text("My age is 20")
                    .shadow(radius: 5)
                    .foregroundColor(.blue)
                    .font(.system(size: 25))
                    .italic()
            }
            HStack {
                Text("🍵🍓🧊")
                    .font(.system(size: 40))
                    .background(Color.gray.opacity(0.3))
                
            }
            Spacer()
                
//            Image(systemName: "globe")
//                .imageScale(.large)
//                .foregroundStyle(.tint)
//            Text("Hello, world!")
            
//            Text("Hello, World!")
//                .font(.largeTitle)
//                .fontWeight(.bold)     //Modifier
//                .padding(.horizontal)
//            
//            Text("Declarative UI | Live Preview | SwiftUI Cool!")
//                .multilineTextAlignment(.center)
//                .padding()
//                .font(.headline)
//                .background(.ultraThinMaterial)
//                .clipShape(RoundedRectangle(cornerRadius: 16))
//            ----
//            HStack {
//                Image(systemName: "sparkles")
//                    .imageScale(.large)
//                    .font(.system(size:100))
//                    .padding()
//                    .overlay(content: {
//                        Circle().strokeBorder(.gray.opacity(0.3),lineWidth: 3)
//                    }
//                    )
//                    .foregroundColor(.pink)
//
//                Text("✨")
//                    .font(.system(size:120))
//            }
//----
//            VStack(spacing: 12) {
//                Text("Strawberry 🍓")
//                Text("Matcha 🍵")
//                Text("Latte ✨")
//            }
            
            // 3 buat vstack di dalam setiap vstack ada emoji yang berbeda
//            VStack(spacing: 12) {
//                Text("🍑")
//                    .font(.system(size:60))
//                Text("🍇")
//                    .font(.system(size:60))
//                Text("🫐")
//                    .font(.system(size:60))
//            }
//            VStack(spacing: 12) {
//                Text("🍉")
//                    .font(.system(size:60))
//                Text("🍐")
//                    .font(.system(size:60))
//                Text("🍒")
//                    .font(.system(size:60))
//            }
//            VStack(spacing: 12) {
//                Text("🍋")
//                    .font(.system(size:60))
//                Text("🍎")
//                    .font(.system(size:60))
//                Text("🥭")
//                    .font(.system(size:60))
//            }
        }
        .padding()
    }
//    let name = "Alice"
//    var age = 28
//    func greet(){
//        print("Hello, \(name), age \(age)")
//    }
    
}

#Preview {
    ContentView()
}
