//
//  W01_RaynaApp.swift
//  W01_Rayna
//
//  Created by student on 11/09/25.
//

import SwiftUI

@main
struct W01_RaynaApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
