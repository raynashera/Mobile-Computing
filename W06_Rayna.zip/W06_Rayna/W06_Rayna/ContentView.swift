//
//  ContentView.swift
//  W06_Rayna
//
//  Created by student on 16/10/25.
//

import SwiftUI

struct ContentView: View {
    // Array
    //@State private var fruits: [String] = ["Apple", "Pear", "Durian"]
    
    //Dictionary: menyimpannya pasangan
//    @State private var scores: [String: Int] = [
//        "Alice": 90,
//        "Martini": 80,
//        "Rose": 70,
//    ]
//    @State private var newStudentName: String = ""
    
    // Class
//    @Observable
//    class Counter {
//        var count: Int = 0
//        func increment()  { count += 1 }
//        func decrement() { count -= 1 }
//    }
//    
//    @State private var counterA = Counter()
//    //@State private var counterB = Counter()
//    @State private var counterB: Counter? = nil //nilai dasar counter B adalah kosong.
    
    // Set
    //gak bisa akses by indeks karena tidak punya urutan dan tidak bisa duplicate
//    @State private var programmingLanguage: Set<String> = ["Swift", "Python", "JavaScript"]
//    @State private var newLang: String = ""
    
    // Tuple
    // cenderung digunakan pada 1 tipe variabel yang sama, bisa menerima value duplikat, tapi urutannya gak bisa berubah.
    // Digunakan untuk data yang kecil, umumnya tuple bentuk Let, bisa diakses by index
//    @State private var point: (x: Int, y: Int) = (x: 0, y: 0)
    
    // Enum
//    enum Grade: String, CaseIterable {
//        case A,B,C,D,E
//        
//        var color: Color {
//            switch self {
//            case .A: return .green
//            case .B: return .yellow
//            case .C: return .orange
//            case .D: return .red
//            case .E: return .blue
//            }
//        }
//    }
//    @State private var grade: Grade = .A
    
    // contoh pengunaan enum
//    enum APIResponse {
//        case success(message: String)
//        case failure(errorCode: Int, reason: String)
//    }
//    
//    let response1 = APIResponse.success(message: "Data loaded!")
//    let response2 = APIResponse.failure(errorCode: 404, reason: "Data not found")
    
//    enum LoadingState {
//        case idle
//        case loading
//        case success(data: String)
//        case error(message: String)
//    }
//    
//    @State private var state: LoadingState = .idle
    
    var body: some View {
        // Contoh 6 Enum
//        VStack {
//            Group {
//                switch state {
//                case .idle:
//                    Text("Tap to start loading")
//                case .loading:
//                    ProgressView("Loading....")
//                case . success(data: let data):
//                    Text("Loaded : \(data)")
//                        .foregroundColor(Color.green)
//                case .error(message: let msg):
//                    Text("Error: \(msg)")
//                        .foregroundColor(Color.red)
//                }
//            }
//            HStack {
//                Button("Start") { state = .loading}
//                Button("Success") { state = .success(data: "KTP mu telah dipload untuk pinjol!")}
//            }
//            Picker("Select Grade", selection: $grade) {
//                ForEach(Grade.allCases, id: \.self) { g in
//                    Text(g.rawValue)
//                }
//            }
//            .pickerStyle(.segmented)
//            
//            Text("Your Grade: \(grade.rawValue)")
//                .font(Font.largeTitle.bold())
//                .foregroundColor(grade.color)
//        }
        
        // Contoh 5 Tuple
//        VStack {
//            Text("Ini adalah Tuple")
//                .font(.largeTitle)
//            
//            Text("Nilai sekarang XY : \(point.x) , \(point.y)")
//            
//            HStack {
//                Button("Kanan 10 langkah") {
//                    point.x += 10
//                } .buttonStyle(.borderedProminent)
//                Button("Kebawah 10 langkah") {
//                    point.y -= 10
//                } .buttonStyle(.borderedProminent)
//            }
//        }
        
        // Contoh 4 Set
//        VStack {
//            Text("Ini adalah Set")
//                .font(.largeTitle)
//            HStack {
//                ForEach(Array(programmingLanguage), id: \.self) {lang in
//                    Text(lang)
//                        .padding(7)
//                        .background(.green)
//                        .clipShape(Capsule())
//                }
//            }
//            HStack {
//                TextField("Enter new language", text: $newLang)
//                    .textFieldStyle(RoundedBorderTextFieldStyle())
//                    .frame(width: 200)
//                
//                Button("Add") {
//                    if !newLang.isEmpty {
//                        programmingLanguage.insert(newLang)
//                        newLang = ""
//                    }
//                }
//                .buttonStyle(.borderedProminent)
//            }
//        }
        
        // Contoh 3 Class
//        VStack {
//            Text("Counter A : \(counterA.count)")
//            Text("Counter B : \(counterB?.count ?? 5)") //menampilkan nilai lain kalau variablel opsional nilainya nul
//                .foregroundStyle(counterB == nil ? .red : .primary)
//            
//            HStack {
//                Button("+") { counterA.increment()}
//                Button("-") { counterA.decrement()}
//                
//                Button(counterB == nil ? "Clone A to B" : "Unlink B") {
//                    if counterB == nil {
//                        counterB = counterA
//                    } else {
//                        counterB = nil
//                    }
//                }.buttonStyle(BorderedButtonStyle())
//                
//                Button("+") { counterB?.increment() }
//            }
//            HStack {
//                Button("+") { counterB.increment()}
//                Button("-") { counterB.decrement()}
//            }
//            
//        }
        
        // Contoh 2 Dictionary
//        VStack {
//            Text("Dictionary Explanation")
//                .font(.largeTitle)
//            VStack {
//                ForEach(scores.sorted(by: {$0.key < $1.key}), id: \.key) { name, score in
//                    HStack {
//                        Text(name)
//                        Spacer()
//                        Text("\(score)")
//                            .bold(true)
//                    }
//                }
//            }
//            .padding(10)
//            
//            VStack {
//                HStack {
//                    Button("Increase Butris' Score!") {
//                        scores["Butris", default: 0] += 5
//                    }
//                    .buttonStyle(.borderedProminent)
//                    
//                    // Buat button untuk delete semua value di Dictionary nya
//                    Button("Delete All Scores") {
//                        scores.removeAll()
//                    }
//                    .buttonStyle(.borderedProminent)
//                }
//                
//                // Buat button untuk menambah nama student sesuai input textfieldnya
//                TextField("Add Student Name", text: $newStudentName)
//                    .textFieldStyle(RoundedBorderTextFieldStyle())
//                    .padding()
//                    .cornerRadius(8)
//                Button("Add Student Name") {
//                    let trimmedName = newStudentName.trimmingCharacters(in: .whitespacesAndNewlines)
//                    if !trimmedName.isEmpty {
//                        scores[trimmedName] = 20
//                        newStudentName = ""
//                    }
//                }
//                .buttonStyle(.borderedProminent)
//            }
//        }
        
        
        // Contoh 1 Array
//        VStack {
//            Text("Array of Fruits")
//                .font(.largeTitle)
//            
//            HStack {
//                ForEach(fruits, id: \.self) {fruit in
//                    Text(fruit)
//                        .padding(10)
//                        .background(Color.orange.opacity(0.3))
//                        .clipShape(Capsule())
//                }
//            }
//            
//            HStack {
//                Button("Add Fruit") {
//                    fruits.append("Banana")
//                }
//                .buttonStyle(.borderedProminent)
//                
//                Button("Remove Last") {
//                    if !fruits.isEmpty {
//                        fruits.removeLast()
//                    }
//                }
//                .buttonStyle(.borderedProminent)
//                
//            }
//        } //vstack

    } //var
} // struct

#Preview {
    ContentView()
}
