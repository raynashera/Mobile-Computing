//
//  W06_RaynaApp.swift
//  W06_Rayna
//
//  Created by student on 16/10/25.
//

import SwiftUI
import CoreData

@main
struct W06_RaynaApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
