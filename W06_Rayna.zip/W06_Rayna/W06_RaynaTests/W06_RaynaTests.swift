//
//  W06_RaynaTests.swift
//  W06_RaynaTests
//
//  Created by student on 16/10/25.
//

import Testing
@testable import W06_Rayna

struct W06_RaynaTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
