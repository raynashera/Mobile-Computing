//
//  W03_RaynaApp.swift
//  W03_Rayna
//
//  Created by student on 25/09/25.
//

import SwiftUI

@main
struct W03_RaynaApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
