//
//  SwiftUIView.swift
//  W03_Rayna
//
//  Created by student on 25/09/25.
//

import SwiftUI

struct SwiftUIView: View {
    var body: some View {
        NavigationStack {
            VStack(spacing: 20) {
                Text("🏡Home Screen")
                    .font(.largeTitle)
                NavigationLink("Go to Details") {
                    DetailScreen()
                }
                NavigationLink("Show Items") {
                    ItemScreen()
                }
            }
        }
    }
}

struct DetailScreen: View {
    var body: some View {
        VStack {
            Text("📑Details Screen")
                .font(.largeTitle)
            Text("You come from Home Screen!")
        }
        .navigationTitle("Detail")
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct ItemScreen: View {
    let items = ["Tomato 🍅", "Edamame 🫛", "Olive 🫒"]
    
    var body: some View {
        List(items, id: \.self) { item in
            NavigationLink(destination: ItemDetailScreen(item:
            item)) {
                Text(item)
            }//bentuknya bisa di klik
        }
        .navigationDestination(for: String.self) { item in
            ItemDetailScreen(item: item)
        } //properti untuk tujuan navigasinya kemana
        .navigationTitle("Items")
    }
}

struct ItemDetailScreen: View {
    let item: String
    var body: some View {
        VStack {
            Text("Welcome to item Detail!")
                .font(.title)
            Text("You Selected: \(item)")
        }
        .navigationTitle(item)
        .navigationBarTitleDisplayMode(.inline)
    }
}


#Preview {
    SwiftUIView()
}
