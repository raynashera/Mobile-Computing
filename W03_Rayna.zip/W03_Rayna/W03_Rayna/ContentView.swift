//
//  ContentView.swift
//  W03_Rayna
//
//  Created by student on 25/09/25.
//

import SwiftUI

struct ContentView2: View {
    var body: some View {
        VStack {
            Text("View 2")
        }
        .padding()
        .background(Color.yellow.opacity(0.4))
    }
}

struct ContentView: View { // Struct itu immutable
    var body: some View {
        // lat 3
        TabView {
            HomeView()
                .tabItem {
                    Label("Home", systemImage:"house.fill")
                }
                .tag(0)
                .badge("3")

            SearchView()
                .tabItem {
                    Label("Search", systemImage:"magnifyingglass")
                }
            
            AccountView()
                .tabItem {
                    Label("Account", systemImage: "person.crop.circle.fill")
                }
                .badge("!")
        }
        .tint(.purple)
    }
}

struct HomeView: View {
    @State private var TextKu = ""
    var body: some View {
        Form {
            VStack {
                Text("🏡Home!")
                    .font(.largeTitle)
                TextField(" Type your name...",text: $TextKu)
                    .border(Color.gray)
                    .padding()
            }
        }
        .padding()
        .background(.blue.opacity(0.2))
    }
}

struct SearchView: View {
    var body: some View {
        Text("👀Search!")
            .font(.largeTitle)
    }
}

struct AccountView: View {
    var body: some View {
        Text("👤Account!")
            .font(.largeTitle)
    }
}

#Preview {
    ContentView()
}
