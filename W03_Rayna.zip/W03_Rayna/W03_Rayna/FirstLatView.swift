//
//  FirstLatView.swift
//  W03_Rayna
//
//  Created by student on 25/09/25.
//

import SwiftUI

struct ContentView3: View {
    var body: some View {
        VStack {
            Text("View 2")
        }
        .padding()
        .background(Color.yellow.opacity(0.4))
    }
}

struct FirstLatView: View {
    //lat 1
    @State private var count = 0
    @State private var nama = ""
    
    //lat 2
    @State private var totalCount = 0
    
    var body: some View {
        VStack {
            //lat 1
            ContentView3()
            Text("Hitung : \(count)")
                .font(.largeTitle)
            Text("Nama : \(nama)")
            TextField("Isi Nama", text: $nama)
                .textFieldStyle(RoundedBorderTextFieldStyle())

            HStack {
                Button("-") {
                    count -= 1
                }
                .font(.largeTitle.bold())
                Button("+") {
                    count += 1
                }
                .font(.largeTitle.bold())
            }
            
            
            //lat 2
            Text("Parent View")
                .font(.largeTitle)
            Text("Total Count: \(totalCount)")
                .font(.title2)
                .padding()

            CounterView(count: $totalCount)
            Spacer()

        }
        .padding()
        .background(.pink.opacity(0.3))
        .cornerRadius(20)
        
    }
}

#Preview {
    FirstLatView()
}
