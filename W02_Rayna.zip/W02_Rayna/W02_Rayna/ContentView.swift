//
//  ContentView.swift
//  W02_Rayna
//
//  Created by student on 18/09/25.
//

import SwiftUI

struct ContentView: View {
    // Declare variable
    let fruits = ["Apple", "Orange", "Banana"]
    
    @State private var isOn: Bool = false
    @State private var volume: Double = 0.5
    @State private var name: String = ""
    
    //CURRENT SCORE
    @State private var point = 80
    private func progressCard(score: Int) -> some View {
        VStack() {
            Text("Current Score").font(.headline)
            ProgressView(value: Double(score), total: 100)
            Text("\(score)/100")
                .foregroundStyle(.secondary)
                
        }
        .padding()
        .background(.green.opacity(0.2))
        .clipShape(RoundedRectangle(cornerRadius: 15))
    }
    private func actionButton(_ title: String, action: @escaping () -> Void) -> some View {
        Button(title, action: action)
            .padding(.horizontal,16)
            .padding(.vertical,10)
            .foregroundColor(.white)
            .background(Color.blue)
            .cornerRadius(10)
    }
    
    var body: some View {
        // Container
//        VStack(spacing: 7) {
            // pengulangan kata
//            ForEach(1...10, id: \.self) {Text("Hello, World! \($0)")
//            }
//            Spacer() //untuk memenuhi container layar, memberikan jarak
//            Text("Rayna")
//            Text("Solo")
//            Text("Rena")
//            Spacer()
//        }
        
        List(fruits, id: \.self) { fruit in
            HStack {
                Text(fruit)
                Spacer()
                Text("u u a a")
            }
        }
        
        //CURRENT SCORE
        VStack {
            progressCard(score: point)
            HStack {
                actionButton("Add 10") {
                    point += 10 }
                actionButton("Reset") { point = 0
                }
            }
        }
            
//            ZStack{
//                RoundedRectangle(cornerRadius: 20)
//                    .fill(.pink.opacity(0.4))
//                    .frame(width: 200, height: 125)
//                    .overlay(
//                        RoundedRectangle(cornerRadius: 20)
//                            .stroke(Color.green.opacity(0.6), lineWidth: 3)
//                    )
//                HStack{
//                    Text("rayna")
//                        .padding(.bottom, 80)
//                        .padding(9)
//                        .padding(.trailing, 50)
//                        .foregroundColor(.white)
//                        .font(.title)
//                    VStack{
//                        Text("🐻")
//                            .padding(.top, 60)
//                        Text("🥭🍑")
//                    }
//                }
//            }
            
//            VStack {
//                Text("Shadow Border")
//                    .padding()
//                    .background(Color.blue.opacity(0.4))
//                    .cornerRadius(30)
//                    .shadow(color: .black, radius: 3, x:10, y:10)
//                    .opacity(0.8)
//            }
//            
//            VStack {
//                Button("tekan saya") {
//                    print("Saya tertekan :(")
//                }
//                .buttonStyle(.bordered) //bisa .bordered atau borderedprominent
//                .tint(.green)
//                
//                Button("tekan saya") {
//                    print("Saya tertekan :(")
//                }
//                .foregroundColor(.white)
//                .padding(10)
//                .background(Color.purple.opacity(0.6))
//                .cornerRadius(18)
//                
//                Image(systemName:"thermometer.variable.and.figure")
//                    .foregroundColor(.red)
//                    .symbolRenderingMode(.hierarchical)
//                    .font(.system(size: 70))
//                
//                
//                Toggle("Enable Notifications", isOn: $isOn)
//                    .padding()
//                Text( isOn ? "yaur" : "naur")
//                
//                Slider(value: $volume, in: 0...1)
//                Text("Volume sekarang : \(volume)%")
//                
//                TextField("Namamu siapa", text: $name)
//                    .padding()
//                    .textFieldStyle(.roundedBorder)
//                //Text("Hello \(name)!")
//                Text(name == "" ? "Hai" : "Hello, \(name)!") // kalau kosong nulis Hai. kalau ada isinya bisa tulis Hello, nama
//                
//            }
    }
}

#Preview {
    ContentView()
}
