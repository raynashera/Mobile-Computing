//
//  W02_RaynaApp.swift
//  W02_Rayna
//
//  Created by student on 18/09/25.
//

import SwiftUI

@main
struct W02_RaynaApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
