//
//  W02_RaynaTests.swift
//  W02_RaynaTests
//
//  Created by student on 18/09/25.
//

import Testing
@testable import W02_Rayna

struct W02_RaynaTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
