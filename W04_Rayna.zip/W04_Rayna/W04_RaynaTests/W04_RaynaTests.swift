//
//  W04_RaynaTests.swift
//  W04_RaynaTests
//
//  Created by student on 02/10/25.
//

import Testing
@testable import W04_Rayna

struct W04_RaynaTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
