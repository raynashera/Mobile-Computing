//
//  MovieCard.swift
//  W04_Rayna
//
//  Created by student on 02/10/25.
//

import SwiftUI

struct MovieCard: View {
    let movie: Movie
    @Binding var isFavorite: Bool
    
    var body: some View {
        ZStack(alignment: .bottomLeading) {
            // Poster (portrait)
            AsyncImage(url: movie.posterURL) { phase in
                switch phase {
                case .empty:
                    Rectangle().fill(.gray.opacity(0.15))
                case .success(let img):
                    img
                        .resizable()
                        .scaledToFill()
                case .failure(_):
                        ZStack {
                        Rectangle().fill(.gray.opacity(0.2))
                        Image(systemName: "film")
                            .font(.system(size: 36, weight: .bold))
                            .foregroundColor(.gray)
                    }
                @unknown default:
                    EmptyView()
                }
            }
            .frame(height: 240)
            .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
            
            VStack {
                HStack {
                    Spacer()
                    Button {
                        isFavorite.toggle()
                    } label: {
                        Image(systemName: isFavorite ? "heart.fill" : "heart")
                            .font(.system(size: 18, weight: .semibold))
                            .foregroundStyle(isFavorite ? .pink : .white)
                            .padding(8)
                            .background(Color.black.opacity(0.35), in: Circle())
                    }
                }
                Spacer()
            }
            .padding(10)

            LinearGradient(colors: [.clear, .black.opacity(0.85)],
                            startPoint: .center, endPoint: .bottom)
                    .clipShape(RoundedRectangle(cornerRadius: 20))
                    .frame(height: 140)
                    .frame(maxHeight: .infinity, alignment: .bottom)
            VStack(alignment: .leading, spacing: 4) {
                Text(movie.title)
                    .font(.headline).bold()
                    .foregroundStyle(.white)
                    .lineLimit(2)
                Text(movie.year)
                    .font(.caption)
                    .foregroundStyle(.white.opacity(0.9))
            }
            .padding(12)
        }
        .overlay(
            RoundedRectangle(cornerRadius: 20)
                .strokeBorder(
                    CardGradients.gradient(for: movie.accentKey),
                    lineWidth: 5
                )
        )
        .shadow(color: .black.opacity(0.15), radius: 8, y: 5)
    }
}
