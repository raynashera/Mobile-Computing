//
//  W04_RaynaApp.swift
//  W04_Rayna
//
//  Created by student on 02/10/25.
//

import SwiftUI

@main
struct W04_RaynaApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
