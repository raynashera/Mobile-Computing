//
//  MovieDetail.swift
//  W04_Rayna
//
//  Created by student on 02/10/25.
//

import SwiftUI

struct MovieDetail: View {
    let movie: Movie
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                ZStack(alignment: .bottomLeading) {
                    AsyncImage(url: movie.posterURL) { phase in
                        switch phase {
                        case .empty:
                            Rectangle().fill(.gray.opacity(0.15))
                        case .success(let img):
                            img.resizable().scaledToFill()
                        case .failure(_):
                            Rectangle().fill(.gray.opacity(0.2))
                        @unknown default: EmptyView()
                        }
                    }
                    .frame(height: 550)
                    .clipShape(RoundedRectangle(cornerRadius: 26, style: .continuous))

                    LinearGradient(colors: [.clear, .black.opacity(0.75)],
                                   startPoint: .center, endPoint: .bottom)
                        .clipShape(RoundedRectangle(cornerRadius: 26))
                        .frame(height: 180)
                        .overlay(
                            VStack(alignment: .leading, spacing: 8) {
                                Text(movie.title)
                                    .font(.title.bold())
                                    .foregroundStyle(.white)
                                HStack {
                                    Text(movie.genres.joined(separator: " • "))
                                        .font(.caption)
                                        .foregroundStyle(.white.opacity(0.95))
                                    Spacer()
                                    Text(movie.year)
                                        .font(.caption)
                                        .foregroundStyle(.white.opacity(0.9))
                                }
                            }
                            .padding(), alignment: .bottomLeading
                        )
                }

                HStack(spacing: 16) {
                    Label(String(format: "%.1f", movie.rating), systemImage: "star.fill")
                        .padding(.horizontal, 12)
                        .padding(.vertical, 9)
                        .background(Color.yellow.opacity(0.3), in: Capsule())
                    Spacer()
                }

                Text("Movie Overview")
                    .font(.headline)
                Text(movie.overview)
                    .foregroundStyle(.secondary)

                Spacer(minLength: 20)
            }
            .padding()
        }
        .navigationTitle(movie.title)
        .navigationBarTitleDisplayMode(.inline)
        .background(
            LinearGradient(
                colors: [Color.blue.opacity(0.3), Color.cyan.opacity(0.3), Color.purple.opacity(0.3)],
                startPoint: .top,
                endPoint: .bottom)
                .ignoresSafeArea()
        )
    }
}

#Preview {
    MovieDetail(movie: Movie(
        title: "The Notebook",
        year: "2004",
        genres: ["Drama", "Romance"],
        rating: 7.9,
        overview: "A romantic drama spanning decades of love and hardship.",
        posterURL: URL(string: "https://image.tmdb.org/t/p/original/rNzQyW4f8B8cQeg7Dgj3n6eT5k9.jpg")!,
        accentKey: "mango"
    ))

}
