//
//  Movie.swift
//  W04_Rayna
//
//  Created by student on 02/10/25.
//

import SwiftUI

struct Movie: Identifiable, Hashable {
    let id = UUID()
    let title: String
    let year: String
    let genres: [String]
    let rating: Double
    let overview: String
    let posterURL: URL
    let accentKey: String
    var isFavorite: Bool = false
}

// Colorful gradients for each card
enum CardGradients {
    static func gradient(for key: String) -> LinearGradient {
            switch key {
            case "sunset":
                return LinearGradient(colors: [Color(#colorLiteral(red:1, green:0.45, blue:0.62, alpha:1)),
                                               Color(#colorLiteral(red:0.58, green:0.38, blue:1, alpha:1))],
                                      startPoint: .topLeading, endPoint: .bottomTrailing)
            case "ocean":
                return LinearGradient(colors: [Color(#colorLiteral(red:0.15, green:0.75, blue:0.93, alpha:1)),
                                               Color(#colorLiteral(red:0.27, green:0.45, blue:0.98, alpha:1))],
                                      startPoint: .topLeading, endPoint: .bottomTrailing)
            case "mango":
                return LinearGradient(colors: [Color(#colorLiteral(red:1, green:0.87, blue:0.33, alpha:1)),
                                               Color(#colorLiteral(red:1, green:0.54, blue:0.22, alpha:1))],
                                      startPoint: .topLeading, endPoint: .bottomTrailing)
            case "mint":
                return LinearGradient(colors: [Color(#colorLiteral(red:0.33, green:0.9, blue:0.76, alpha:1)),
                                               Color(#colorLiteral(red:0.41, green:0.73, blue:0.98, alpha:1))],
                                      startPoint: .topLeading, endPoint: .bottomTrailing)
            case "grape":
                return LinearGradient(colors: [Color(#colorLiteral(red:0.55, green:0.36, blue:1, alpha:1)),
                                               Color(#colorLiteral(red:0.94, green:0.34, blue:0.82, alpha:1))],
                                      startPoint: .topLeading, endPoint: .bottomTrailing)
            default: // flame
                return LinearGradient(colors: [Color(#colorLiteral(red:1, green:0.36, blue:0.36, alpha:1)),
                                               Color(#colorLiteral(red:1, green:0.65, blue:0.28, alpha:1))],
                                      startPoint: .topLeading, endPoint: .bottomTrailing)
            }
        }

}
