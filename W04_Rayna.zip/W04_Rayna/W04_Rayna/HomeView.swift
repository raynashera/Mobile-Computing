//
//  HomeView.swift
//  W04_Rayna
//
//  Created by student on 02/10/25.
//

import SwiftUI

struct HomeView: View {
    @StateObject private var store = MovieStore()
    @State private var showFavoritesOnly = false
    
    private let columns = [
        GridItem(.flexible(), spacing: 16),
        GridItem(.flexible(), spacing: 16)
    ]
    
    private var filteredIndices: [Int] {
        let q = store.query.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        return store.movies.indices.filter { i in
            let m = store.movies[i]
            let matchesQuery = q.isEmpty ||
                m.title.lowercased().contains(q) ||
                m.year.lowercased().contains(q) ||
                m.genres.joined(separator: ",").lowercased().contains(q)
            let matchesFavorite = !showFavoritesOnly || m.isFavorite

            return matchesQuery && matchesFavorite
        }
    }


    var body: some View {
        ScrollView {
            VStack(spacing: 16) {
                SearchBar(text: $store.query)
                    .padding(.horizontal)
                
                HStack {
                    Button {
                        showFavoritesOnly.toggle()
                    } label: {
                        Label(showFavoritesOnly ? "Show All" : "Show Favorites",
                              systemImage: showFavoritesOnly ? "film.stack" : "heart.fill")
                            .font(.subheadline.bold())
                            .padding(.horizontal, 12)
                            .padding(.vertical, 8)
                            .foregroundColor(.white)
                            .background(showFavoritesOnly ? Color.pink : Color.blue, in: Capsule())
                    }
                    Spacer()
                }
                .padding(.horizontal)


                LazyVGrid(columns: columns, spacing: 16) {
                    ForEach(filteredIndices, id: \.self) { i in
                        let movie = store.movies[i]
                        NavigationLink {
                            MovieDetail(movie: movie)
                        } label: {
                            MovieCard(movie: movie,
                                              isFavorite: $store.movies[i].isFavorite)
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(.horizontal)
                .padding(.bottom, 24)
            }
            .padding(.top, 8)
        }
        .background(
            LinearGradient(colors: [Color.blue.opacity(0.3),
                                    Color.cyan.opacity(0.3),
                                    Color.purple.opacity(0.3)],
                           startPoint: .topLeading,
                           endPoint: .bottomTrailing)
            .ignoresSafeArea()
        )

    }

}

#Preview {
    HomeView()
}
