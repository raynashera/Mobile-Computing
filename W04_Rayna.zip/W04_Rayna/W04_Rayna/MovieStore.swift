//
//  MovieStore.swift
//  W04_Rayna
//
//  Created by student on 02/10/25.
//

import SwiftUI
import Combine

final class MovieStore: ObservableObject {
    @Published var movies: [Movie] = []
    @Published var query: String = ""
    
    init() {
        movies = [
            Movie(
                title: "Spirited Away",
                year: "2001",
                genres: ["Animation", "Fantasy"],
                rating: 8.6,
                overview: "Ten-year-old Chihiro and her parents end up at an abandoned amusement park inhabited by supernatural beings. Soon, she learns that she must work to free her parents who have been turned into pigs.",
                posterURL: URL(string: "https://image.tmdb.org/t/p/original/39wmItIWsg5sZMyRUHLkWBcuVCM.jpg")!,
                accentKey: "mint"
            ),
            Movie(
                title: "The Princess Diaries",
                year: "2001",
                genres: ["Comedy", "Family"],
                rating: 6.4,
                overview: "A clumsy, shy teen discovers that she's the princess of a small European state. She is then coached and must prove that she is worthy of her title while trying to make it through her school year.",
                posterURL: URL(string: "https://image.tmdb.org/t/p/original/qSw4lzhDGeM5MjQc86BLzJALhBs.jpg")!,
                accentKey: "sunset"
            ),
            Movie(
                title: "How to Lose a Guy in 10 Days",
                year: "2003",
                genres: ["Romance", "Comedy"],
                rating: 6.5,
                overview: "Andie, a magazine writer, meets her date Benjamin, a marketing executive, after she decides to write a special column while he makes a bet. Unaware of their real intentions, they fall in love.",
                posterURL: URL(string: "https://image.tmdb.org/t/p/original/2dlftyPz7mTYbrsPvTogyFmYd7d.jpg")!,
                accentKey: "mango"
            ),
            Movie(
                title: "The Notebook",
                year: "2004",
                genres: ["Romance", "Drama"],
                rating: 7.9,
                overview: "Noah, a poor man, falls in love with Allie who comes from wealth. They are forced to keep passion for each other aside due to societal pressure and a difference in the social stature of their families.",
                posterURL: URL(string: "https://image.tmdb.org/t/p/original/28HcbSyLA3SlgmXSEnt5gOPaiKH.jpg")!,
                accentKey: "grape"
            ),
            Movie(
                title: "Crazy Rich Asians",
                year: "2018",
                genres: ["Romance", "Comedy"],
                rating: 6.9,
                overview: "Rachel, a professor, dates a man named Nick and looks forward to meeting his family. However, she is shaken up when she learns that Nick belongs to one of the richest families in the country.",
                posterURL: URL(string: "https://image.tmdb.org/t/p/original/1XxL4LJ5WHdrcYcihEZUCgNCpAW.jpg")!,
                accentKey: "ocean"
            ),
            Movie(
                title: "The Proposal",
                year: "2009",
                genres: ["Romance", "Comedy"],
                rating: 6.7,
                overview: "In order to avoid deportation to Canada, Margaret, the editor of a publishing firm, convinces her assistant Andrew to marry her. However, a trip to Andrew's hometown leads to unexpected consequences.",
                posterURL: URL(string: "https://image.tmdb.org/t/p/original/aEqtJDj8MvSDQwzggvcOfFTZMw.jpg")!,
                accentKey: "flame"
            )
        ]
    }
}

