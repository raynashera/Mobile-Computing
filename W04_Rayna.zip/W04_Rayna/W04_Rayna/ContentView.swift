//
//  ContentView.swift
//  W04_Rayna
//
//  Created by student on 02/10/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationStack {
            HomeView()
                .navigationTitle("🎬UCFlix")
                .navigationBarTitleDisplayMode(.large)
            
        }
    }
}

#Preview {
    ContentView()
}
